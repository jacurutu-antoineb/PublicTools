# Cookie Monster

Chrome extension that steals Okta cookie and send to a remote server.
This is used for SE demo purpose.

To use it, Chrome developer mode needs to be turned on for now. You can then `Load unpacked` this extension.

## Configuration

### ServerUrl

You can change the server URL where cookies are sent by clicking on the
extension icon and selecting *option*. The default is set to localhost `http://127.0.0.1:8998`.

## Supported services

- Okta
- Office 365
- SFDC

## Usage
nc -k -l 8998
1. Create a new Chrome profile for demo
2. Installl the extension with extension developer mode turned on
3. Configure the ServerUrl once
4. (As an attacker) Launch console and run `nc -k -l <port>` on the server configured
5. (As a victim) Login to supported service
6. (As an attacker) Login to VPN to simmulate an attacker
7. (As an attacker) Copy the cookies from console & paste cookise to EditThisCookie extension in another browser profile as if you are the attacker. Ideally to another browser like Firefox, which is beneficial for other demos later on
6. (As an attacker) Visit the targeted service

