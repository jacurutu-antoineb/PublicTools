import enum
import json
import re
import typing

import pyarrow as pa
from pydantic import BaseModel, root_validator, validator, Field, StrictBool, StrictInt, StrictFloat


VALUE_TYPE = None | StrictBool | StrictInt | StrictFloat | str | list[str]
MAX_STRING_SIZE = 256
MAX_SETTINGS_COUNT = 1000
VALID_ID_REGEX = re.compile(r"^[a-zA-Z0-9._-]+$")


class SettingType(enum.StrEnum):
    BOOLEAN = "bool"
    NUMBER = "number"
    STRING = "string"
    STRING_ARRAY = "string_array"


class PlatformSettingModel(BaseModel):
    id: str = Field(max_length=128)
    name: str
    type: SettingType
    value: VALUE_TYPE


class PlatformSettingV1_0(PlatformSettingModel):
    @validator("id")
    def validate_id(cls, value):
        if not VALID_ID_REGEX.match(value):
            raise ValueError(
                "Only alphanumeric characters, periods, underscores, and dashes are allowed."
            )
        return value

    @validator("value")
    def validate_string_length(cls, value_: VALUE_TYPE, values: dict[str, typing.Any]):
        type_ = values.get("type")

        if type_ == SettingType.STRING:
            value_ = typing.cast(str, value_)
            if len(value_) > MAX_STRING_SIZE:
                raise ValueError(f"Value exceeds max string length of {MAX_STRING_SIZE}.")
        elif type_ == SettingType.STRING_ARRAY:
            if isinstance(value_, str):
                value_ = json.loads(value_)

            if isinstance(value_, list):
                for val in value_:
                    if len(val) > MAX_STRING_SIZE:
                        raise ValueError(f"Value exceeds max string length of {MAX_STRING_SIZE}.")
            else:
                raise ValueError("Value must be a list of strings")

        return value_

    @root_validator(pre=False)
    def validate_type_and_value(cls, values: dict[str, typing.Any]):
        type_ = values.get("type")
        value_raw = values.get("value")

        # No validation if value is None
        if value_raw is None:
            return type_

        if type_ == SettingType.BOOLEAN:
            if not isinstance(value_raw, bool):
                raise ValueError("`value` must be a bool for `boolean` type`.")
        elif type_ == SettingType.NUMBER:
            if not isinstance(value_raw, int) and not isinstance(value_raw, float):
                raise ValueError("`value` must be an int or float for `number` type`.")
        elif type_ == SettingType.STRING:
            if not isinstance(value_raw, str):
                raise ValueError("`value` must be a str for `string` type.")
        elif type_ == SettingType.STRING_ARRAY:
            if not isinstance(value_raw, list):
                raise ValueError("`value` must be a list for `string_array` type.")
            for val in value_raw:
                if not isinstance(val, str):
                    raise ValueError("`value` must be a list of strings for `string_array` type.")
        else:
            raise ValueError(f"Unknown `type`: {type_}.")

        return values

    def asdict(self):
        data = dict(self)
        data["value"] = json.dumps(data["value"])
        return data


SETTING_MODEL_MAP: dict[str, type[PlatformSettingModel]] = {
    "1.0": PlatformSettingV1_0,
}


SETTING_SCHEMA_MAP: dict[str, pa.Schema] = {
    "1.0": pa.schema(
        [
            pa.field("id", pa.string()),
            pa.field("name", pa.string()),
            pa.field("type", pa.string()),
            pa.field("value", pa.string()),
        ]
    )
}
