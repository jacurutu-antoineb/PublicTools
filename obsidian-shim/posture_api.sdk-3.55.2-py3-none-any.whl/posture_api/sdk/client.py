import io
import os
import logging
import uuid

import pydantic
import pyarrow as pa
import pyarrow.parquet as pq
import requests

from posture_api.sdk.setting import (
    PlatformSettingV1_0,
    SETTING_SCHEMA_MAP,
    SETTING_MODEL_MAP,
    MAX_SETTINGS_COUNT,
)

from posture_api.sdk.account import (
    PlatformAccountV1_0,
    ACCOUNT_MODEL_MAP,
    ACCOUNT_SCHEMA_MAP,
    MAX_ACCOUNTS_COUNT,
)


API_ENV_OVERRIDE = "OBSEC_API_ENDPOINT"
API_ENDPOINTS: dict[str, str] = {"live": "https://api.obsec.io", "eu": "https://api.obsec.eu"}


class ObsidianBYODClient:
    def __init__(self, api_key: str, env: str = "live"):
        """
        Obsidian Security BYOD Client

        Parameters
        ----------
        api_key : str
            JWT Token
        env : str
            Determines which Obsidian API endpoint to access. Defaults to "live".
        """
        self.logger = logging.getLogger("obsec.byod.client")
        self.api_key = api_key
        self.session = requests.Session()
        self.session.headers.update({"authorization": f"Bearer {self.api_key}"})

        if (endpoint := os.getenv(API_ENV_OVERRIDE)) is not None:
            self.api_endpoint = endpoint
        else:
            self.api_endpoint = API_ENDPOINTS[env]

        self.logger.info(f"Initializing ObsidianBYODClient with endpoint: {self.api_endpoint}")

    def close(self):
        """
        Closes the session
        """
        self.session.close()

    def raise_for_status(self, resp: requests.Response):
        """
        Logs and re-raises any failed HTTP requests

        Parameters
        ----------
        resp : requests.Response
            Response object returned from requests call
        """
        try:
            resp.raise_for_status()
        except requests.HTTPError as exc:
            detail = resp.json().get("detail")
            self.logger.exception(f"Error communicating with Obsidian API: {detail}")
            raise exc
        except Exception as exc:
            self.logger.exception("Error communicating with Obsidian API")
            raise exc

    def upload_settings(
        self,
        service_id: uuid.UUID,
        tenant_id: str,
        version: str,
        records: list[PlatformSettingV1_0],
    ) -> int:
        """
        Uploads a list of settings for a custom service/tenant to Obsidian Security's Posture Management

        Parameters
        ----------
        service_id: uuid.UUID
            Service ID returned from creating a custom connection

        tenant_id: str
            Unique tenant identifer for uploaded data

        version: str
            Schema version string for uploaded data format

        Returns
        -------
        int
            Number of bytes uploaded
        """

        # Endpoint settings
        url = "/v1_0/byod/upload/settings"
        data = {
            "platform_id": service_id,
            "tenant_id": tenant_id,
            "schema_version": version,
        }

        # Enforce maximum settings count
        if (count := len(records)) > MAX_SETTINGS_COUNT:
            msg = f"List of settings ({count}) exceeds supported maximum: {MAX_SETTINGS_COUNT}."
            self.logger.exception(msg)
            raise ValueError(msg)

        seen = set()
        model = SETTING_MODEL_MAP[version]

        for row in records:
            # Run model validation
            if error := pydantic.validate_model(model, row.__dict__)[2]:
                self.logger.exception("Error validating setting", exc_info=error)
                raise error

            # Check for duplicates
            if row.id in seen:
                raise ValueError(f"Duplicate setting detected: {row.id}")

            seen.add(row.id)

        self.logger.debug(f"Successfully validated {len(records)} records.")

        # Generate Pyarrow table
        schema = SETTING_SCHEMA_MAP[data["schema_version"]]
        settings_dict = [obj.asdict() for obj in records]
        table = pa.Table.from_pylist(settings_dict, schema=schema)

        # Dump to in-memory parquet file
        buf = io.BytesIO()
        writer = pq.ParquetWriter(buf, schema=schema)
        writer.write_table(table)
        writer.close()
        buf.seek(0)
        size = buf.getbuffer().nbytes

        # Upload file to API
        files = {"file": buf}
        resp = self.session.put(f"{self.api_endpoint}{url}", data=data, files=files)
        buf.close()

        self.logger.info(f"Uploaded {size} bytes to {url}. Response code: {resp.status_code}")

        # Check for error
        self.raise_for_status(resp)

        return size

    def upload_accounts(
        self,
        service_id: uuid.UUID,
        tenant_id: str,
        version: str,
        records: list[PlatformAccountV1_0],
    ) -> int:
        """
        Uploads a list of accounts for a custom service/tenant to Obsidian Security's Posture Management

        Parameters
        ----------
        service_id: uuid.UUID
            Service ID returned from creating a custom connection

        tenant_id: str
            Unique tenant identifer for uploaded data

        version: str
            Schema version string for uploaded data format

        Returns
        -------
        int
            Number of bytes uploaded
        """

        # Endpoint settings
        url = "/v1_0/byod/upload/accounts"
        data = {
            "platform_id": service_id,
            "tenant_id": tenant_id,
            "schema_version": version,
        }

        # Enforce maximum settings count
        if (count := len(records)) > MAX_ACCOUNTS_COUNT:
            msg = f"List of users ({count}) exceeds supported maximum: {MAX_ACCOUNTS_COUNT}."
            self.logger.exception(msg)
            raise ValueError(msg)

        # Run model validation
        model = ACCOUNT_MODEL_MAP[version]
        for row in records:
            if error := pydantic.validate_model(model, row.__dict__)[2]:
                self.logger.exception("Error validating setting.", exc_info=error)
                raise error

        self.logger.debug(f"Successfully validated {len(records)} records.")

        # Generate Pyarrow table
        schema = ACCOUNT_SCHEMA_MAP[data["schema_version"]]
        user_dict = [obj.asdict() for obj in records]
        table = pa.Table.from_pylist(user_dict, schema=schema)

        # Dump to in-memory parquet file
        buf = io.BytesIO()
        writer = pq.ParquetWriter(buf, schema=schema)
        writer.write_table(table)
        writer.close()
        buf.seek(0)
        size = buf.getbuffer().nbytes

        # Upload file to API
        files = {"file": buf}
        resp = self.session.put(f"{self.api_endpoint}{url}", data=data, files=files)
        buf.close()

        self.logger.info(f"Uploaded {size} bytes to {url}. Response code: {resp.status_code}")

        # Check for error
        self.raise_for_status(resp)

        return size
