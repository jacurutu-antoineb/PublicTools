from datetime import datetime

import pyarrow as pa
from pydantic import BaseModel, Field


MAX_ACCOUNTS_COUNT = 100000


class PlatformAccountModel(BaseModel):
    id: str = Field(description="Unique identifier for user")
    name: str = Field(description="User's full name")
    email: str = Field(description="User's e-mail address")
    username: str = Field(description="User's username")
    department: str | None = Field(description="User's department")
    title: str = Field(description="User's job title")
    groups: set[str] = Field(description="Array of user's group membership", default_factory=list)
    roles: set[str] = Field(description="Array of user's roles", default_factory=list)
    permissions: set[str] = Field(description="Array of user's permissions", default_factory=list)
    integration_user: bool = Field(
        description="Indicates if user is a service integration account", default=False
    )
    enabled: bool = Field(description="Indicates if the account is enabled")
    local_login_enabled: bool = Field(
        description="Indicates if local login is enabled for the user", default=True
    )
    sso_enabled: bool = Field(
        description="Indicates if Single Sign-On is enabled for the user", default=False
    )
    sso_enforced: bool = Field(
        description="Indicates if Single Sign-On is enforced for the user", default=False
    )
    mfa_enforced: bool = Field(
        description="Indicates if Multi-Factor Authentication is enforced for the user",
        default=False,
    )
    timeout: int = Field(description="User's session timeout in minutes", default=0)
    last_successful_login: datetime | None = Field(
        description="Date and time of the user's last successful login", default=None
    )
    created_on: datetime = Field(description="Date and time the user was created")
    created_by: str = Field(description="E-mail of the user or process that created the user")
    updated_on: datetime = Field(description="Date and time the user was last updated")
    updated_by: str | None = Field(
        description="E-mail of the user or process that updated the user"
    )


class PlatformAccountV1_0(PlatformAccountModel):
    def asdict(self):
        data = dict(self)
        data["id"] = str(data["id"])
        if self.last_successful_login is not None:
            data["last_successful_login"] = self.last_successful_login.isoformat()

        data["created_on"] = data["created_on"].isoformat()
        data["updated_on"] = data["updated_on"].isoformat()
        return data


ACCOUNT_MODEL_MAP: dict[str, type[PlatformAccountModel]] = {
    "1.0": PlatformAccountModel,
}


ACCOUNT_SCHEMA_MAP: dict[str, pa.Schema] = {
    "1.0": pa.schema(
        [
            pa.field("id", pa.string()),
            pa.field("name", pa.string()),
            pa.field("email", pa.string()),
            pa.field("username", pa.string()),
            pa.field("department", pa.string()),
            pa.field("title", pa.string()),
            pa.field("groups", pa.list_(pa.string())),
            pa.field("roles", pa.list_(pa.string())),
            pa.field("permissions", pa.list_(pa.string())),
            pa.field("integration_user", pa.bool_()),
            pa.field("enabled", pa.bool_()),
            pa.field("local_login_enabled", pa.bool_()),
            pa.field("sso_enabled", pa.bool_()),
            pa.field("sso_enforced", pa.bool_()),
            pa.field("mfa_enforced", pa.bool_()),
            pa.field("timeout", pa.int64()),
            pa.field("last_successful_login", pa.string()),
            pa.field("created_on", pa.string()),
            pa.field("created_by", pa.string()),
            pa.field("updated_on", pa.string()),
            pa.field("updated_by", pa.string()),
        ]
    )
}
