import logging
import uuid

from posture_api.sdk.setting import PlatformSettingV1_0
from posture_api.sdk.client import ObsidianBYODClient


# API access token generated from Step 1
API_TOKEN = "Obsidian JWT Token"

# Service ID generated from Step 2
SERVICE_ID = uuid.UUID("4cb953f0-1972-47fc-a0af-cc3c3ab4fb39")

# Generate your own identifiers for different tenants within this SaaS application (alphanumeric, dashes, underscore)
DEV_TENANT_ID = "dev-app-internal"

# (Optional) Setup logging
logging.basicConfig(level="DEBUG")

# Example settings from a SaaS application
# (id, name, value, type)
# type must be 1 of: bool, number, string, string_array (see posture_api.sdk.setting.SettingType)
saas_settings = [
    (
        "user.management.account.lock.timeout",
        "Account Lock Timeout",
        "number",
        15,
    ),
    (
        "security.access.ip.whitelist",
        "IP Whitelist",
        "string_array",
        ["192.168.1.0/24", "10.0.0.0/8"],
    ),
    ("notifications.emails.welcome.enabled", "Welcome E-Mails", "bool", True),
    ("storage.files.max.size", "Max File Size", "number", 1024),
    (
        "collaboration.sharing.link.expiry",
        "Shared Link Expiry",
        "number",
        7.5,
    ),
    ("dashboard.color.theme", "Color Theme", "string", "dark"),
]

# Parse settings data into PlatformSetting model
settings: list[PlatformSettingV1_0] = []
for row in saas_settings:
    obj = PlatformSettingV1_0(id=row[0], name=row[1], type=row[2], value=row[3])
    settings.append(obj)


# Create Obsidian Security BYOD Client
client = ObsidianBYODClient(API_TOKEN)

# Upload settings for dev tenant
client.upload_settings(
    service_id=SERVICE_ID, tenant_id=DEV_TENANT_ID, version="1.0", records=settings
)

# Cleanup
client.close()
