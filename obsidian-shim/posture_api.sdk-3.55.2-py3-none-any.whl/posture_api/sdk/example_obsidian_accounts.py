import logging
import requests
import uuid

from posture_api.sdk.account import PlatformAccountV1_0
from posture_api.sdk.client import ObsidianBYODClient


# API access token generated from Step 1
API_TOKEN = "Obsidian JWT Token"

# Service ID generated from Step 2
SERVICE_ID = uuid.UUID("ac4186ef-b843-4e3d-9ea8-919eebce5ed8")

# Generate your own identifiers for different tenants within this SaaS application (alphanumeric, dashes, underscore)
DEV_TENANT_ID = "obsidian-dev-tenant"

# (Optional) Setup logging
logging.basicConfig(level="DEBUG")

# Account data
accounts = []

# Get account data from Obsidian
session = requests.Session()
session.headers.update({"Authorization": f"Bearer {API_TOKEN}"})
endpoint = "https://api.obsec.io/v1/users"
params = {
    "page_size": 100,
    "page_token": "",
}

while params["page_token"] is not None:
    resp = session.get(endpoint, params=params)
    data = resp.json()

    # Transform raw data into PlatformAccountV1_0 model
    for row in data["results"]:
        obj = PlatformAccountV1_0(
            id=row["id"],
            name=row["name"],
            email=row["email"],
            username=row["preferred_username"],
            department=None,
            title=row["job_title"],
            # groups={},
            roles={row["role"]},
            permissions={x["service"] for x in row["tenant_privileges"]},
            # integration_user=False,
            enabled=row["status"] == "ACTIVE",
            local_login_enabled=row["type"] == "LOCAL",
            sso_enabled=row["type"] == "SSO",
            sso_enforced=row["type"] == "SSO",
            mfa_enforced=row["mfa_enabled"],
            # timeout=0,
            # last_successful_login=None,
            created_on=row["create_time"],
            created_by=row["inviter_id"],
            updated_on=row["update_time"],
            updated_by=None,
        )
        accounts.append(obj)

    # No more data if `next_page_token` is empty string
    if (next_page_token := data.get("next_page_token", "")) == "":
        next_page_token = None
    params["page_token"] = next_page_token


# Create Obsidian Security BYOD Client
client = ObsidianBYODClient(API_TOKEN)

# Upload settings for dev tenant
client.upload_accounts(
    service_id=SERVICE_ID, tenant_id=DEV_TENANT_ID, version="1.0", records=accounts
)

# Cleanup
client.close()
